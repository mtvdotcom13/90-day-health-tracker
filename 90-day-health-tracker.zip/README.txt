90-Day Health Tracker PWA

Upload all six files in this folder to the ROOT of a GitHub repository, then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).

Open the published HTTPS URL in iPhone Safari and use Share > Add to Home Screen.

Entries are stored locally in the browser. Export a JSON backup regularly. Do not upload private diary backups to a public repository.
